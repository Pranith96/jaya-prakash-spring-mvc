package com.wdf.springmvc.model;

public enum Gender {

	MALE, FEMALE
}
